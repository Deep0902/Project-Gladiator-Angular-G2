export class LogIn{
    accountId:number;
    logId:number;
    logInPassword:string;
    transactionPassword:string;
}