export class UserAccountDetail{
    accountId:number;
    customerId:number;
    balance:number;
    accOpDate:Date;
    accountStatus:boolean;
}