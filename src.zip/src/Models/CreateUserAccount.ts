export class CreateUserAccount{
    customerId:number;
    balance:number;
    accOpDate:string;
    accountStatus:boolean;
}