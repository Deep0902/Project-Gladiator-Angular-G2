export class Payee{
    payeeId:number;
    beneficiaryAccount:number;
    beneficiaryName:string;
    nickName:string;
    accountId:number;
}